Execució:
	Per consola:
	java -jar DriverItem.jar
	
	Incloent el fitxer d'entrada:
	java -jar DriverItem.jar < input.in > output.txt
