ItemsType data.
