Execució:
	Per consola:
	java DriverManagerRecommendation
	
	Incloent el fitxer d'entrada:
	java DriverManagerRecommendation < input.in > output.txt
	
