CSVFile data of the CSV files.
