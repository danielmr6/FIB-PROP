Execució:
	Per consola:
	java -jar DriverActiveUser.jar
	
	Incloent el fitxer d'entrada:
	java -jar DriverActiveUser.jar < input.in > output.txt
