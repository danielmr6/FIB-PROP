DOCS: Conté l'únic document on hi es tota la documentació, es a dir, 
la documentació del casos d'us, la documentació del UML, descripció 
de les estructures de dades i algorismes utilitzats per implementar
les funcionalitats principals, llista de clases que ha fet cada membre
del grup i relació de llibreries externes.


