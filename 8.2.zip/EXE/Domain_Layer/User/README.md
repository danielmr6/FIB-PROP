Execució:
	Per consola:
	java -jar DriverUser.jar
	
	Incloent el fitxer d'entrada:
	java -jar DriverUser.jar < input.in > output.txt
