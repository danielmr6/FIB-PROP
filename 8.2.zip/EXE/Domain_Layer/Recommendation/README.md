Execució:
	Per consola:
	java -jar DriverRecommendation.jar
	
	Incloent el fitxer d'entrada:
	java -jar DriverRecommendation.jar < input.in > output.txt
