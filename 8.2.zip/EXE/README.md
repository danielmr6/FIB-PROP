EXE: Executables per provar totes les clases i funcionalitats 
implementades i jocs de prova. Hi haurà un subdirectori per 
cada classe a provar, amb el executables necesaris i els diferents
jocs de prova.
