Execució:
	Per consola:
	java -jar DriverPair.jar
	
	Incloent el fitxer d'entrada:
	java -jar DriverPair.jar < input.in > output.txt
