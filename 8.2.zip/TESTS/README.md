TEST: Hi haurà els tests unitaris de codi fets en JUnit d'una part del
projecte, que ho indicaran.
