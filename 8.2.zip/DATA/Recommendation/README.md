Recommendation data.
