Execució:
	Per consola:
	java DriverCtrlDataLayer
	
	Incloent el fitxer d'entrada:
	java DriverCtrlDataLayer < input1.in > output1.txt
	java DriverCtrlDataLayer < input2.in > output2.txt
	java DriverCtrlDataLayer < input3.in > output3.txt
