Execució:
	Per consola:
	java -jar DriverReview.jar
	
	Incloent el fitxer d'entrada:
	java -jar DriverReview.jar < input.in > output.txt
