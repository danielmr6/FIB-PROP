Valoration data.
