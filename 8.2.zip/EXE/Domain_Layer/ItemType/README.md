Execució:
	Per consola:
	java -jar DriverItemType.jar
	
	Incloent el fitxer d'entrada:
	java -jar DriverItemType.jar < input.in > output.txt
